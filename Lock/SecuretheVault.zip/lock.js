//alert("You have received this message because you have been chosen to open an important vault! here is the secret combination:");

//let name= prompt("Enter a number:");
//console.log(print, name);

//create 3 variables 
//each variable a result of arithmetic 
// first result must equal 10  - each of these must use + or x or divide 
// second result must equal 40 
// third result must equal 39 
// create a message and assemble combination 
let result1; // =10 
let result2; //=40
let result3; //=39 
//created variables for the combination
    let results1= 5  * 2;
    let results2= 10 + 30;
    let results3= 40 - 1; 

//storing message as const makes the code less cluttered when using it as an alert
    const message = "You have received this message because you have been chosen to open an important vault! Here is the secret combination:"

    alert(`${message} ${results1} - ${results2} - ${results3}`);

// assemble combination 

// console log 
//const message = "you have recieved this message because.."
//console.log(`${message} ${result}-${result2}-${result3}`)

//{} - means that we are entering some javascript into it 





//expected output: I enjoy programming in Javascript!
//decalring variables 

//psuedocode
/* create a popup that spits out the message
popup message directs users to enter variables 
direct user entered variable to add x to equal 10, 40, or 39
each calculation must each either 10, 40, or 39. 
store the code 
print out the code in a dialog box displaying the vault codes and ext or create a popup dialogue*/